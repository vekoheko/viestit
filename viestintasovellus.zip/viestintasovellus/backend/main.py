"""Viestintäsovellus: käyttäjät, ryhmät, reaaliaikainen chat ja äänestykset.

FastAPI + WebSocket + SQLite.
"""
import os
import secrets

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db

app = FastAPI(title="Viestintäsovellus")

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")

db.init_db()

# Demotasoinen istunnonhallinta muistissa: token -> käyttäjänimi.
sessions: dict[str, str] = {}

# Admin-koodilla avautuvat admin-istunnot: admin_token -> True.
# Koodi tarkistetaan vain palvelimella, se ei koskaan näy frontend-koodissa.
ADMIN_CODE = "1982125"
admin_sessions: set[str] = set()


def current_user(token: str) -> str:
    username = sessions.get(token)
    if username is None:
        raise HTTPException(401, "Kirjaudu sisään uudelleen.")
    return username


def require_admin(admin_token: str):
    if admin_token not in admin_sessions:
        raise HTTPException(401, "Admin-istunto on vanhentunut tai virheellinen.")


class Credentials(BaseModel):
    username: str
    password: str


class AdminCode(BaseModel):
    code: str


class ApproveRequest(BaseModel):
    username: str


class GroupCreate(BaseModel):
    name: str


class PollCreate(BaseModel):
    question: str
    options: list[str]


class VoteRequest(BaseModel):
    option_id: int


# --- Yhteyksienhallinta ryhmittäin --------------------------------------

class ConnectionManager:
    def __init__(self):
        # group_id -> { username: WebSocket }
        self.groups: dict[int, dict[str, WebSocket]] = {}

    async def connect(self, group_id: int, username: str, websocket: WebSocket):
        await websocket.accept()
        self.groups.setdefault(group_id, {})[username] = websocket

    def disconnect(self, group_id: int, username: str):
        if group_id in self.groups:
            self.groups[group_id].pop(username, None)
            if not self.groups[group_id]:
                del self.groups[group_id]

    async def broadcast(self, group_id: int, message: dict):
        stale = []
        for username, ws in self.groups.get(group_id, {}).items():
            try:
                await ws.send_json(message)
            except Exception:
                stale.append(username)
        for username in stale:
            self.disconnect(group_id, username)


manager = ConnectionManager()


# --- Autentikointi --------------------------------------------------------

@app.post("/api/register")
def register(creds: Credentials):
    username = creds.username.strip()
    if not username or not creds.password:
        raise HTTPException(400, "Käyttäjätunnus ja salasana vaaditaan.")
    if len(creds.password) < 4:
        raise HTTPException(400, "Salasanan tulee olla vähintään 4 merkkiä.")
    created = db.create_user(username, creds.password)
    if not created:
        raise HTTPException(409, "Käyttäjätunnus on jo varattu.")
    return {"ok": True}


@app.post("/api/login")
def login(creds: Credentials):
    username = creds.username.strip()
    if not db.verify_user(username, creds.password):
        raise HTTPException(401, "Väärä käyttäjätunnus tai salasana.")
    if not db.is_approved(username):
        raise HTTPException(
            403, "Tili odottaa admin-hyväksyntää. Yritä myöhemmin uudelleen."
        )
    token = secrets.token_urlsafe(32)
    sessions[token] = username
    return {"token": token, "username": username}


# --- Admin ------------------------------------------------------------------

@app.post("/api/admin/login")
def admin_login(payload: AdminCode):
    if payload.code.strip() != ADMIN_CODE:
        raise HTTPException(401, "Väärä koodi.")
    admin_token = secrets.token_urlsafe(32)
    admin_sessions.add(admin_token)
    return {"admin_token": admin_token}


@app.get("/api/admin/pending")
def admin_pending(admin_token: str):
    require_admin(admin_token)
    return db.list_pending_users()


@app.post("/api/admin/approve")
def admin_approve(payload: ApproveRequest, admin_token: str):
    require_admin(admin_token)
    approved = db.approve_user(payload.username.strip())
    if not approved:
        raise HTTPException(404, "Käyttäjää ei löytynyt.")
    return {"ok": True}


# --- Ryhmät ----------------------------------------------------------------

@app.get("/api/groups")
def groups():
    return db.list_groups()


@app.post("/api/groups")
def create_group(payload: GroupCreate, token: str):
    username = current_user(token)
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Ryhmän nimi vaaditaan.")
    return db.create_group(name, username)


@app.post("/api/groups/{group_id}/join")
def join_group(group_id: int, token: str):
    username = current_user(token)
    if not db.group_exists(group_id):
        raise HTTPException(404, "Ryhmää ei löytynyt.")
    db.join_group(group_id, username)
    return {"ok": True}


# --- Viestit -----------------------------------------------------------

@app.get("/api/groups/{group_id}/messages")
def group_messages(group_id: int, limit: int = 50):
    if not db.group_exists(group_id):
        raise HTTPException(404, "Ryhmää ei löytynyt.")
    return db.get_messages(group_id, limit)


# --- Äänestykset ------------------------------------------------------------

@app.get("/api/groups/{group_id}/polls")
def group_polls(group_id: int, token: str):
    username = current_user(token)
    if not db.group_exists(group_id):
        raise HTTPException(404, "Ryhmää ei löytynyt.")
    return db.get_polls(group_id, username)


@app.post("/api/groups/{group_id}/polls")
async def create_poll(group_id: int, payload: PollCreate, token: str):
    username = current_user(token)
    if not db.group_exists(group_id):
        raise HTTPException(404, "Ryhmää ei löytynyt.")
    question = payload.question.strip()
    options = [o.strip() for o in payload.options if o.strip()]
    if not question:
        raise HTTPException(400, "Kysymys vaaditaan.")
    if len(options) < 2:
        raise HTTPException(400, "Äänestyksessä tulee olla vähintään 2 vaihtoehtoa.")
    db.join_group(group_id, username)
    poll = db.create_poll(group_id, question, username, options)
    await manager.broadcast(group_id, {"type": "poll_created", "poll": poll})
    return poll


@app.post("/api/polls/{poll_id}/vote")
async def vote_poll(poll_id: int, payload: VoteRequest, token: str):
    username = current_user(token)
    poll = db.vote(poll_id, payload.option_id, username)
    if poll is None:
        raise HTTPException(404, "Äänestystä tai vaihtoehtoa ei löytynyt.")
    # Lähetetään kaikille ryhmän jäsenille päivitetyt äänimäärät, mutta
    # ilman "my_vote" -kenttää, joka on käyttäjäkohtainen.
    public_poll = {**poll, "my_vote": None}
    await manager.broadcast(poll["group_id"], {"type": "poll_update", "poll": public_poll})
    return poll


# --- WebSocket-chat ryhmittäin -----------------------------------------

@app.websocket("/ws/{token}/{group_id}")
async def websocket_endpoint(websocket: WebSocket, token: str, group_id: int):
    username = sessions.get(token)
    if username is None or not db.group_exists(group_id):
        await websocket.close(code=4401)
        return

    db.join_group(group_id, username)
    await manager.connect(group_id, username, websocket)
    await manager.broadcast(
        group_id, {"type": "system", "content": f"{username} liittyi ryhmään."}
    )
    try:
        while True:
            data = await websocket.receive_text()
            text = data.strip()
            if not text:
                continue
            message = db.save_message(group_id, username, text)
            message["type"] = "message"
            await manager.broadcast(group_id, message)
    except WebSocketDisconnect:
        manager.disconnect(group_id, username)
        await manager.broadcast(
            group_id, {"type": "system", "content": f"{username} poistui ryhmästä."}
        )


# Staattiset tiedostot viimeisenä, jotta /api/* ja /ws/* ehtivät ensin.
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))
