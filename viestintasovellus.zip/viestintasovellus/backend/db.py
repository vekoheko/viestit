"""SQLite-pohjainen tallennus käyttäjille, ryhmille, viesteille ja äänestyksille."""
import hashlib
import os
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(__file__), "chat.db")


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                approved INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT ''
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS group_members (
                group_id INTEGER NOT NULL REFERENCES groups(id),
                username TEXT NOT NULL,
                PRIMARY KEY (group_id, username)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL REFERENCES groups(id),
                username TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS polls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL REFERENCES groups(id),
                question TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS poll_options (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poll_id INTEGER NOT NULL REFERENCES polls(id),
                text TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS poll_votes (
                poll_id INTEGER NOT NULL REFERENCES polls(id),
                username TEXT NOT NULL,
                option_id INTEGER NOT NULL REFERENCES poll_options(id),
                PRIMARY KEY (poll_id, username)
            )
            """
        )

        # Migraatio: vanhemmissa tietokannoissa users-taulusta puuttuvat
        # approved/created_at-sarakkeet. Olemassa olevat tunnukset
        # merkitään automaattisesti hyväksytyiksi, koska ne on luotu ennen
        # admin-hyväksyntäjärjestelmää.
        existing_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()
        }
        if "approved" not in existing_columns:
            conn.execute(
                "ALTER TABLE users ADD COLUMN approved INTEGER NOT NULL DEFAULT 1"
            )
        if "created_at" not in existing_columns:
            conn.execute("ALTER TABLE users ADD COLUMN created_at TEXT NOT NULL DEFAULT ''")


def _hash_password(password: str, salt: str) -> str:
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# --- Käyttäjät ---------------------------------------------------------

def create_user(username: str, password: str) -> bool:
    """Luo uuden käyttäjän odottavaan (ei-hyväksyttyyn) tilaan."""
    salt = secrets.token_hex(16)
    password_hash = _hash_password(password, salt)
    with get_conn() as conn:
        existing = conn.execute(
            "SELECT 1 FROM users WHERE username = ?", (username,)
        ).fetchone()
        if existing:
            return False
        conn.execute(
            "INSERT INTO users (username, salt, password_hash, approved, created_at) "
            "VALUES (?, ?, ?, 0, ?)",
            (username, salt, password_hash, _now()),
        )
    return True


def verify_user(username: str, password: str) -> bool:
    """Tarkistaa vain salasanan oikeellisuuden, ei hyväksyntätilaa."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT salt, password_hash FROM users WHERE username = ?", (username,)
        ).fetchone()
        if row is None:
            return False
        return _hash_password(password, row["salt"]) == row["password_hash"]


def is_approved(username: str) -> bool:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT approved FROM users WHERE username = ?", (username,)
        ).fetchone()
        return bool(row and row["approved"])


def list_pending_users() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT username, created_at FROM users WHERE approved = 0 "
            "ORDER BY created_at ASC"
        ).fetchall()
    return [dict(row) for row in rows]


def approve_user(username: str) -> bool:
    with get_conn() as conn:
        cursor = conn.execute(
            "UPDATE users SET approved = 1 WHERE username = ?", (username,)
        )
        return cursor.rowcount > 0


# --- Ryhmät -------------------------------------------------------------

def create_group(name: str, created_by: str) -> dict:
    with get_conn() as conn:
        cursor = conn.execute(
            "INSERT INTO groups (name, created_by, created_at) VALUES (?, ?, ?)",
            (name, created_by, _now()),
        )
        group_id = cursor.lastrowid
        conn.execute(
            "INSERT OR IGNORE INTO group_members (group_id, username) VALUES (?, ?)",
            (group_id, created_by),
        )
        return {"id": group_id, "name": name, "created_by": created_by}


def list_groups() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT g.id, g.name, g.created_by, g.created_at,
                   (SELECT COUNT(*) FROM group_members m WHERE m.group_id = g.id) AS member_count
            FROM groups g
            ORDER BY g.created_at DESC
            """
        ).fetchall()
    return [dict(row) for row in rows]


def group_exists(group_id: int) -> bool:
    with get_conn() as conn:
        return (
            conn.execute("SELECT 1 FROM groups WHERE id = ?", (group_id,)).fetchone()
            is not None
        )


def join_group(group_id: int, username: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO group_members (group_id, username) VALUES (?, ?)",
            (group_id, username),
        )


def is_member(group_id: int, username: str) -> bool:
    with get_conn() as conn:
        return (
            conn.execute(
                "SELECT 1 FROM group_members WHERE group_id = ? AND username = ?",
                (group_id, username),
            ).fetchone()
            is not None
        )


# --- Viestit --------------------------------------------------------------

def save_message(group_id: int, username: str, content: str) -> dict:
    created_at = _now()
    with get_conn() as conn:
        cursor = conn.execute(
            "INSERT INTO messages (group_id, username, content, created_at) "
            "VALUES (?, ?, ?, ?)",
            (group_id, username, content, created_at),
        )
        return {
            "id": cursor.lastrowid,
            "group_id": group_id,
            "username": username,
            "content": content,
            "created_at": created_at,
        }


def get_messages(group_id: int, limit: int = 50) -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, group_id, username, content, created_at FROM messages "
            "WHERE group_id = ? ORDER BY id DESC LIMIT ?",
            (group_id, limit),
        ).fetchall()
    return [dict(row) for row in reversed(rows)]


# --- Äänestykset ----------------------------------------------------------

def create_poll(group_id: int, question: str, created_by: str, options: list[str]) -> dict:
    with get_conn() as conn:
        cursor = conn.execute(
            "INSERT INTO polls (group_id, question, created_by, created_at) "
            "VALUES (?, ?, ?, ?)",
            (group_id, question, created_by, _now()),
        )
        poll_id = cursor.lastrowid
        for text in options:
            conn.execute(
                "INSERT INTO poll_options (poll_id, text) VALUES (?, ?)",
                (poll_id, text),
            )
    return get_poll(poll_id)


def get_poll(poll_id: int, username: str | None = None) -> dict | None:
    with get_conn() as conn:
        poll_row = conn.execute(
            "SELECT id, group_id, question, created_by, created_at FROM polls WHERE id = ?",
            (poll_id,),
        ).fetchone()
        if poll_row is None:
            return None
        option_rows = conn.execute(
            """
            SELECT o.id, o.text,
                   (SELECT COUNT(*) FROM poll_votes v WHERE v.option_id = o.id) AS votes
            FROM poll_options o
            WHERE o.poll_id = ?
            ORDER BY o.id
            """,
            (poll_id,),
        ).fetchall()
        my_vote = None
        if username:
            my_vote_row = conn.execute(
                "SELECT option_id FROM poll_votes WHERE poll_id = ? AND username = ?",
                (poll_id, username),
            ).fetchone()
            if my_vote_row:
                my_vote = my_vote_row["option_id"]

    poll = dict(poll_row)
    poll["options"] = [dict(row) for row in option_rows]
    poll["my_vote"] = my_vote
    return poll


def get_polls(group_id: int, username: str | None = None) -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id FROM polls WHERE group_id = ? ORDER BY id DESC",
            (group_id,),
        ).fetchall()
    return [get_poll(row["id"], username) for row in rows]


def vote(poll_id: int, option_id: int, username: str) -> dict | None:
    with get_conn() as conn:
        option_row = conn.execute(
            "SELECT poll_id FROM poll_options WHERE id = ?", (option_id,)
        ).fetchone()
        if option_row is None or option_row["poll_id"] != poll_id:
            return None
        conn.execute(
            "INSERT INTO poll_votes (poll_id, username, option_id) VALUES (?, ?, ?) "
            "ON CONFLICT(poll_id, username) DO UPDATE SET option_id = excluded.option_id",
            (poll_id, username, option_id),
        )
    return get_poll(poll_id, username)
