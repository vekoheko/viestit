// --- Elementit ---------------------------------------------------------

const authScreen = document.getElementById("auth-screen");
const appScreen = document.getElementById("app-screen");
const authForm = document.getElementById("auth-form");
const authError = document.getElementById("auth-error");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const loginBtn = document.getElementById("login-btn");
const registerBtn = document.getElementById("register-btn");
const logoutBtn = document.getElementById("logout-btn");
const whoami = document.getElementById("whoami");
const whoamiAvatar = document.getElementById("whoami-avatar");
const toastContainer = document.getElementById("toast-container");

const adminEntryBtn = document.getElementById("admin-entry-btn");
const adminModalOverlay = document.getElementById("admin-modal-overlay");
const adminCodeInput = document.getElementById("admin-code-input");
const adminError = document.getElementById("admin-error");
const adminCancelBtn = document.getElementById("admin-cancel-btn");
const adminSubmitBtn = document.getElementById("admin-submit-btn");
const adminScreen = document.getElementById("admin-screen");
const adminLogoutBtn = document.getElementById("admin-logout-btn");
const pendingList = document.getElementById("pending-list");

const newGroupForm = document.getElementById("new-group-form");
const newGroupName = document.getElementById("new-group-name");
const groupList = document.getElementById("group-list");

const noGroup = document.getElementById("no-group");
const groupView = document.getElementById("group-view");
const groupTitle = document.getElementById("group-title");
const tabBtns = document.querySelectorAll(".tab-btn");
const tabMessages = document.getElementById("tab-messages");
const tabPolls = document.getElementById("tab-polls");

const messagesEl = document.getElementById("messages");
const messageForm = document.getElementById("message-form");
const messageInput = document.getElementById("message-input");

const pollsEl = document.getElementById("polls");
const newPollForm = document.getElementById("new-poll-form");
const pollQuestion = document.getElementById("poll-question");
const pollOptionsEl = document.getElementById("poll-options");
const addOptionBtn = document.getElementById("add-option-btn");

// --- Tila ----------------------------------------------------------------

let token = localStorage.getItem("token");
let username = localStorage.getItem("username");
let socket = null;
let currentGroup = null; // { id, name }
let pollsCache = {}; // poll_id -> poll
let adminToken = null;

// --- Ilmoitukset (toast) ----------------------------------------------

function showToast(message, type = "error") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("toast-leaving");
    setTimeout(() => toast.remove(), 200);
  }, 3200);
}

// --- Nappien lataustila -------------------------------------------------

function withLoading(button, label, fn) {
  const original = button.innerHTML;
  return async (...args) => {
    button.disabled = true;
    button.innerHTML = `<span class="spinner"></span>${label}`;
    try {
      return await fn(...args);
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  };
}

// --- Apufunktiot -----------------------------------------------------

function showError(msg) {
  authError.className = "error";
  authError.textContent = msg;
  authError.hidden = false;
}

function showNotice(msg) {
  authError.className = "notice";
  authError.textContent = msg;
  authError.hidden = false;
}

function clearError() {
  authError.hidden = true;
  authError.textContent = "";
}

function initials(name) {
  return (name || "?").slice(0, 2);
}

async function api(path, options = {}) {
  const url = new URL(path, location.origin);
  if (options.auth !== false) {
    url.searchParams.set("token", token);
  }
  const res = await fetch(url, {
    method: options.method || "GET",
    headers: options.body ? { "Content-Type": "application/json" } : undefined,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || "Pyyntö epäonnistui.");
  }
  return data;
}

// --- Autentikointi -----------------------------------------------------

async function submitCredentials(endpoint) {
  clearError();
  const body = {
    username: usernameInput.value.trim(),
    password: passwordInput.value,
  };
  if (!body.username || !body.password) {
    showError("Täytä käyttäjätunnus ja salasana.");
    return;
  }
  try {
    const res = await fetch(`/api/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) {
      showError(data.detail || "Jokin meni pieleen.");
      return;
    }
    if (endpoint === "register") {
      showNotice("Pyyntö lähetetty! Odota admin-hyväksyntää ennen kirjautumista.");
      return;
    }
    token = data.token;
    username = data.username;
    localStorage.setItem("token", token);
    localStorage.setItem("username", username);
    enterApp();
  } catch (err) {
    showError("Yhteysvirhe palvelimeen.");
  }
}

const handleLogin = withLoading(loginBtn, "Kirjaudutaan…", () => submitCredentials("login"));
const handleRegister = withLoading(registerBtn, "Luodaan…", () => submitCredentials("register"));

authForm.addEventListener("submit", (e) => {
  e.preventDefault();
  handleLogin();
});

registerBtn.addEventListener("click", () => handleRegister());

logoutBtn.addEventListener("click", logout);

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  token = null;
  username = null;
  currentGroup = null;
  if (socket) {
    socket.close();
    socket = null;
  }
  appScreen.hidden = true;
  authScreen.hidden = false;
  authForm.reset();
}

function enterApp() {
  authScreen.hidden = true;
  appScreen.hidden = false;
  whoami.textContent = username;
  whoamiAvatar.textContent = initials(username);
  loadGroups();
}

// --- Ryhmät ----------------------------------------------------------------

async function loadGroups() {
  const groups = await api("/api/groups", { auth: false });
  groupList.innerHTML = "";
  if (groups.length === 0) {
    groupList.innerHTML = '<li class="group-list-empty">Ei ryhmiä vielä — luo ensimmäinen yllä.</li>';
    return;
  }
  groups.forEach((g) => {
    const li = document.createElement("li");
    if (currentGroup && currentGroup.id === g.id) li.classList.add("active");
    const label = document.createElement("span");
    label.textContent = g.name;
    const count = document.createElement("span");
    count.className = "member-count";
    count.textContent = `${g.member_count} 👤`;
    li.appendChild(label);
    li.appendChild(count);
    li.addEventListener("click", () => selectGroup(g));
    groupList.appendChild(li);
  });
}

newGroupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = newGroupName.value.trim();
  if (!name) return;
  const submitBtn = newGroupForm.querySelector("button[type=submit]");
  try {
    const group = await withLoading(submitBtn, "", () =>
      api("/api/groups", { method: "POST", body: { name } })
    )();
    newGroupName.value = "";
    await loadGroups();
    selectGroup(group);
  } catch (err) {
    showToast(err.message);
  }
});

async function selectGroup(group) {
  currentGroup = group;
  noGroup.hidden = true;
  groupView.hidden = false;
  groupTitle.textContent = group.name;
  await loadGroups();

  try {
    await api(`/api/groups/${group.id}/join`, { method: "POST", body: {} });
  } catch (err) {
    /* ei kriittinen */
  }

  messagesEl.innerHTML = "";
  pollsEl.innerHTML = "";
  await Promise.all([loadMessages(group.id), loadPolls(group.id)]);
  connectSocket(group.id);
}

// --- WebSocket --------------------------------------------------------

function connectSocket(groupId) {
  if (socket) {
    socket.close();
  }
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  socket = new WebSocket(`${protocol}//${location.host}/ws/${token}/${groupId}`);

  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === "message" || data.type === "system") {
      renderMessage(data);
    } else if (data.type === "poll_created") {
      upsertPoll(data.poll);
    } else if (data.type === "poll_update") {
      upsertPoll(data.poll, { keepMyVote: true });
    }
  };

  socket.onclose = (event) => {
    if (event.code === 4401) {
      showToast("Istunto vanhentui, kirjaudu sisään uudelleen.");
      logout();
    }
  };
}

// --- Viestit -----------------------------------------------------------

function renderMessage({ type, username: from, content, created_at }) {
  if (type === "system") {
    const el = document.createElement("div");
    el.className = "msg-system";
    el.textContent = content;
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return;
  }

  const row = document.createElement("div");
  row.className = "msg-row" + (from === username ? " own" : "");

  const avatar = document.createElement("span");
  avatar.className = "avatar";
  avatar.textContent = initials(from);

  const bubble = document.createElement("div");
  bubble.className = "msg";
  const time = created_at
    ? new Date(created_at).toLocaleTimeString("fi-FI", { hour: "2-digit", minute: "2-digit" })
    : "";
  const meta = document.createElement("span");
  meta.className = "meta";
  meta.textContent = `${from} · ${time}`;
  const textNode = document.createElement("span");
  textNode.textContent = content;
  bubble.appendChild(meta);
  bubble.appendChild(textNode);

  row.appendChild(avatar);
  row.appendChild(bubble);
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function loadMessages(groupId) {
  const history = await api(`/api/groups/${groupId}/messages?limit=50`, { auth: false });
  messagesEl.innerHTML = "";
  history.forEach((m) => renderMessage({ ...m, type: "message" }));
}

messageForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = messageInput.value.trim();
  if (!text || !socket || socket.readyState !== WebSocket.OPEN) return;
  socket.send(text);
  messageInput.value = "";
});

// --- Äänestykset ------------------------------------------------------

async function loadPolls(groupId) {
  const polls = await api(`/api/groups/${groupId}/polls`);
  pollsCache = {};
  pollsEl.innerHTML = "";
  if (polls.length === 0) {
    pollsEl.innerHTML = '<p class="poll-empty">Ei äänestyksiä vielä. Luo ensimmäinen alla. 🗳️</p>';
  }
  polls.forEach((poll) => upsertPoll(poll));
}

function upsertPoll(poll, { keepMyVote } = {}) {
  if (keepMyVote && pollsCache[poll.id]) {
    poll.my_vote = pollsCache[poll.id].my_vote;
  }
  pollsCache[poll.id] = poll;
  renderPolls();
}

function renderPolls() {
  const emptyMsg = pollsEl.querySelector(".poll-empty");
  if (emptyMsg) emptyMsg.remove();

  Object.values(pollsCache)
    .sort((a, b) => b.id - a.id)
    .forEach((poll) => {
      let card = document.getElementById(`poll-${poll.id}`);
      if (!card) {
        card = document.createElement("div");
        card.className = "poll-card";
        card.id = `poll-${poll.id}`;
        pollsEl.prepend(card);
      }
      const totalVotes = poll.options.reduce((sum, o) => sum + o.votes, 0);
      card.innerHTML = `
        <h4>${escapeHtml(poll.question)}</h4>
        <div class="poll-meta">Luonut ${escapeHtml(poll.created_by)} · ${totalVotes} äänt${totalVotes === 1 ? "i" : "ä"}</div>
      `;
      poll.options.forEach((opt) => {
        const pct = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
        const optEl = document.createElement("div");
        optEl.className = "poll-option" + (poll.my_vote === opt.id ? " selected" : "");
        optEl.innerHTML = `
          <div class="bar" style="width: ${pct}%"></div>
          <span class="label">${escapeHtml(opt.text)}</span>
          <span class="count">${opt.votes} (${pct}%)</span>
        `;
        optEl.addEventListener("click", () => castVote(poll.id, opt.id));
        card.appendChild(optEl);
      });
    });
}

async function castVote(pollId, optionId) {
  try {
    const poll = await api(`/api/polls/${pollId}/vote`, {
      method: "POST",
      body: { option_id: optionId },
    });
    pollsCache[pollId] = poll;
    renderPolls();
  } catch (err) {
    showToast(err.message);
  }
}

addOptionBtn.addEventListener("click", () => {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "poll-option-input";
  input.placeholder = `Vaihtoehto ${pollOptionsEl.children.length + 1}`;
  pollOptionsEl.appendChild(input);
  input.focus();
});

newPollForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentGroup) return;
  const question = pollQuestion.value.trim();
  const options = [...pollOptionsEl.querySelectorAll(".poll-option-input")]
    .map((i) => i.value.trim())
    .filter(Boolean);
  if (!question || options.length < 2) {
    showToast("Anna kysymys ja vähintään 2 vaihtoehtoa.");
    return;
  }
  const submitBtn = newPollForm.querySelector("button[type=submit]");
  try {
    await withLoading(submitBtn, "Luodaan…", () =>
      api(`/api/groups/${currentGroup.id}/polls`, {
        method: "POST",
        body: { question, options },
      })
    )();
    pollQuestion.value = "";
    pollOptionsEl.innerHTML =
      '<input class="poll-option-input" type="text" placeholder="Vaihtoehto 1" />' +
      '<input class="poll-option-input" type="text" placeholder="Vaihtoehto 2" />';
    showToast("Äänestys luotu!", "success");
  } catch (err) {
    showToast(err.message);
  }
});

// --- Välilehdet -------------------------------------------------------

tabBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    tabBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    tabMessages.hidden = tab !== "messages";
    tabPolls.hidden = tab !== "polls";
  });
});

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// --- Admin --------------------------------------------------------------

function openAdminModal() {
  adminError.hidden = true;
  adminCodeInput.value = "";
  adminModalOverlay.hidden = false;
  adminCodeInput.focus();
}

function closeAdminModal() {
  adminModalOverlay.hidden = true;
}

adminEntryBtn.addEventListener("click", openAdminModal);
adminCancelBtn.addEventListener("click", closeAdminModal);

adminCodeInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    submitAdminCode();
  }
});

adminSubmitBtn.addEventListener("click", () => submitAdminCode());

async function submitAdminCode() {
  adminError.hidden = true;
  const code = adminCodeInput.value.trim();
  if (!code) {
    adminError.textContent = "Syötä koodi.";
    adminError.hidden = false;
    return;
  }
  try {
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    const data = await res.json();
    if (!res.ok) {
      adminError.textContent = data.detail || "Väärä koodi.";
      adminError.hidden = false;
      return;
    }
    adminToken = data.admin_token;
    closeAdminModal();
    enterAdminPanel();
  } catch (err) {
    adminError.textContent = "Yhteysvirhe palvelimeen.";
    adminError.hidden = false;
  }
}

function enterAdminPanel() {
  authScreen.hidden = true;
  adminScreen.hidden = false;
  loadPendingUsers();
}

function exitAdminPanel() {
  adminToken = null;
  adminScreen.hidden = true;
  authScreen.hidden = false;
}

adminLogoutBtn.addEventListener("click", exitAdminPanel);

async function loadPendingUsers() {
  try {
    const url = new URL("/api/admin/pending", location.origin);
    url.searchParams.set("admin_token", adminToken);
    const res = await fetch(url);
    const pending = await res.json();
    if (!res.ok) {
      showToast(pending.detail || "Pyyntöjen lataus epäonnistui.");
      exitAdminPanel();
      return;
    }
    renderPendingUsers(pending);
  } catch (err) {
    showToast("Yhteysvirhe palvelimeen.");
  }
}

function renderPendingUsers(pending) {
  pendingList.innerHTML = "";
  if (pending.length === 0) {
    pendingList.innerHTML = '<li class="pending-empty">Ei odottavia pyyntöjä. 🎉</li>';
    return;
  }
  pending.forEach((user) => {
    const li = document.createElement("li");

    const info = document.createElement("div");
    info.className = "pending-info";
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.textContent = initials(user.username);
    const texts = document.createElement("div");
    texts.innerHTML = `<div class="username">${escapeHtml(user.username)}</div>`;
    info.appendChild(avatar);
    info.appendChild(texts);

    const approveBtn = document.createElement("button");
    approveBtn.className = "btn-primary";
    approveBtn.textContent = "Hyväksy";
    approveBtn.addEventListener("click", () =>
      withLoading(approveBtn, "Hyväksytään…", () => approveUser(user.username, li))()
    );

    li.appendChild(info);
    li.appendChild(approveBtn);
    pendingList.appendChild(li);
  });
}

async function approveUser(username, listItem) {
  try {
    const url = new URL("/api/admin/approve", location.origin);
    url.searchParams.set("admin_token", adminToken);
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.detail || "Hyväksyminen epäonnistui.");
      return;
    }
    listItem.remove();
    if (pendingList.children.length === 0) {
      pendingList.innerHTML = '<li class="pending-empty">Ei odottavia pyyntöjä. 🎉</li>';
    }
    showToast(`${username} hyväksytty!`, "success");
  } catch (err) {
    showToast("Yhteysvirhe palvelimeen.");
  }
}

// --- Käynnistys -------------------------------------------------------

if (token && username) {
  enterApp();
}
